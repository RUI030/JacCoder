# jac reference-solution failures on function-eval-v1 (test split)
**What this is.** Nitin's function-eval-v1 bundle ships 500 completion problems. Each problem carries a `reference_completion` — the canonical answer that, when concatenated to the visible `prefix`, must (a) pass `jac check` and (b) pass the hidden `test_blocks` under `jac test`. This report lists the 9 references that fail on the CURRENT local jac toolchain, so downstream model-evaluation can attribute those problems to the toolchain instead of the model.
**Toolchain.** `jac 0.36.0` (Linux x86_64). Grader is `graders/eval_jac.py` from `jac-data-gen` @ commit `dc2935e9…`, patched only to emit per-test pass/fail (see `PROVENANCE.md`).
**Sample size.** Broken **9 / 500** = **1.8%**. Prior dev-split run (2026-09-12) was 15/200 = 7.5%; the drop reflects fixed jac compiler / infra bugs — see the tail of this document.
## How to reproduce
Each case ships as its own folder under `cases/<problem_id>/`:
- `candidate.jac` — visible prefix + reference_completion concatenated, exactly as the grader assembles it
- `tests.jac`     — the hidden test blocks
- `guard.jac`     — an includes-driven driver equivalent to what the grader writes to /tmp
- `error.txt`     — the concise stderr the grader captured

Reproduce a single case from that folder:

```bash
cd cases/<problem_id>
jac check candidate.jac         # step 1: static check
jac test  guard.jac             # step 2: run hidden tests
```
Reproduce the whole batch against the shipping bundle (requires the JacCoder repo checkout):

```bash
python script/eval/Nitin-test/wash_refs.py --split test --field reference_completion --timeout 180
```
The pass ends by writing `refs_ok.txt` and `refs_broken.txt`.

---

## Per-case detail
### `fn-complete-180850` — jac_native_runtime
- **Grader status:** `test_fail`  |  per_test: **17/18**
- **Reason:** Crash in jac's native test invocation path (`invoke_native_test`). The reference compiled but the native runner faulted while executing tests.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-180850 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
eval_fn-complete-180850_ru1eanch/guard.jac:2 in test_t0
    def find_primes(n: int) -> list[int] {
  /home/runner/work/jac/jac/.zig-cache/o/6809e14a8d43797bd6d65d7a7807b009/payload.tar.zst.work/site/jaclang/runtimelib/impl/test.impl.jac:207 in invoke_native_test
E   AssertionError: assertion failed at /tmp/jac_eval_fn-complete-180850_ru1eanch/guard.jac:15
=========================== short test summary info ============================
FAILED guard.jac::t0 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c0...
========================= 1 failed, 17 passed in 5.28s =========================
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""Finds all the primes below number n using the sieve of Eratosthenes."""
def find_primes(n: int) -> list[int] {
    candidates = [(i + 2) for i in range(n - 1)];
    for p in candidates {
        for i in candidates {
            if i % p == 0 and p != i {
                candidates.remove(i);
            }
        }
    }
    return candidates;
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (find_primes(1) == []);;
}

test "t1" {
    assert (find_primes(13) == [2, 3, 5, 7, 11, 13]);;
}

test "t2" {
    assert (
        find_primes(100)
        == [
            2,
            3,
            5,
            7,
            11,
            13,
            17,
            19,
            23,
            29,
            31,
            37,
            41,
            43,
            47,
            53,
            59,
            61,
            67,
            71,
            73,
            79,
            83,
            89,
            97
        ]
    );;
}

test "t3" {
    assert (
        find_primes(50) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
    );;
}

test "t4" {
    assert (find_primes(20) == [2, 3, 5, 7, 11, 13, 17, 19]);;
}

test "t5" {
    assert (find_primes(4) == [2, 3]);;
}

test "t6" {
    assert (find_primes(10) == [2, 3, 5, 7]);;
}

test "t7" {
    assert (find_primes(15) == [2, 3, 5, 7, 11, 13]);;
}

test "t8" {
    assert (find_primes(7) == [2, 3, 5, 7]);;
}

test "t9" {
    assert (find_primes(6) == [2, 3, 5]);;
}

test "t10" {
    assert (find_primes(11) == [2, 3, 5, 7, 11]);;
}

test "t11" {
    assert (find_primes(8) == [2, 3, 5, 7]);;
}

test "t12" {
    assert (find_primes(9) == [2, 3, 5, 7]);;
}

test "t13" {
    assert (find_primes(30) == [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]);;
}

test "t14" {
    assert (find_primes(12) == [2, 3, 5, 7, 11]);;
}

test "t15" {
    assert (find_primes(5) == [2, 3, 5
```
</details>

---

### `fn-complete-448774` — jac_native_runtime
- **Grader status:** `test_fail`  |  per_test: **12/22**
- **Reason:** Crash in jac's Rust runtime module (`c/rt/…`). Native execution path fault.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-448774 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
ocal/bin/jac" [0x147c96f]
  Binary file "/home/imrui/.local/bin/jac" [0x147c5d3]
  Binary file "/usr/lib/x86_64-linux-gnu/libc.so.6", at +0x45cb0 [0x7779d2c45cb0]
  Binary file "/usr/lib/x86_64-linux-gnu/libc.so.6", at pthread_kill+0x11c [0x7779d2ca61ac]
  Binary file "/usr/lib/x86_64-linux-gnu/libc.so.6", at gsignal+0x1e [0x7779d2c45b7e]
  Binary file "/home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c00d5c6c3/python/lib/libpython3.14.so", at +0x2aae28 [0x7779d14aae28]
  Binary file "/usr/lib/x86_64-linux-gnu/libc.so.6", at +0x45cb0 [0x7779d2c45cb0]
  Binary file '<unknown>' [0x7779d2ea68a2]
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""
    Extract all (and only) the path vars in a dictionary.

    :param d: a .paths.json data structure
    :return: all path var definitions without any special entries like '__ENV'
    """
def path_vars_in(d: dict[str, object]) -> list[tuple[str, object]] {
    return [p for p in d.items() if p[0] != '__ENV'];
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (
        path_vars_in({"${a}": {"name": "a", "type": "string"}, "__ENV": {"foo": "bar"}})
        == [("${a}", {"name": "a", "type": "string"})]
    );;
}

test "t1" {
    assert (
        path_vars_in({'a': 'b', 'c': 'd', 'e': 'f', 'g': 'h', 'i': 'j', 'k': 'l'})
        == [('a', 'b'), ('c', 'd'), ('e', 'f'), ('g', 'h'), ('i', 'j'), ('k', 'l')]
    );;
}

test "t2" {
    assert (
        path_vars_in({'a': 'b', 'c': 'd', '__ENV': 'e', 'g': 'h'})
        == [('a', 'b'), ('c', 'd'), ('g', 'h')]
    );;
}

test "t3" {
    assert (path_vars_in({"x": "foo", "y": "bar"}) == [("x", "foo"), ("y", "bar")]);;
}

test "t4" {
    assert (
        path_vars_in(
            {
                'foo': {'path': 'foo.txt'},
                'bar': {'path': 'bar.txt'},
                '__ENV': {'x': 1, 'y': 2}
            }
        )
        == [('foo', {'path': 'foo.txt'}), ('bar', {'path': 'bar.txt'})]
    );;
}

test "t5" {
    assert (
        path_vars_in({"path_var": {"type": "path_var", "default": 2}})
        == [("path_var", {"type": "path_var", "default": 2})]
    );;
}

test "t6" {
    assert (
        path_vars_in(
            {
                "__ENV": {"foo": {"default": "foo"}},
                "bar": {"default": "bar", "type": "file", "env": "BAR"}
            }
        )
        == [("bar", {"default": "bar", "type": "file", "env": "BAR"})]
    );;
}

test "t7" {
    assert (
        path_vars_in({"path_var": {"type": "path_var", "default": [2, 2]}})
    
```
</details>

---

### `fn-complete-205247` — jac_typecheck_or_data
- **Grader status:** `check_fail`  |  per_test: **0/0**
- **Reason:** E1002 return type mismatch (float vs int). Either the reference is genuinely mistyped (dataset), or jac's type checker got stricter and now rejects previously accepted code.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-205247 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
✖ Error: error[E1002]: Cannot return float, expected int
  --> /tmp/jac_eval_fn-complete-205247_lib0mgvm/candidate.jac:2:40
    1 | """Determine the nth digit of an integer, starting at the right and counting from zero."""
    2 | def _nth_digit(i: int, n: int) -> int {return (i // (10 ** n)) % 10;
      |                                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    3 | }
    4 |
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""Determine the nth digit of an integer, starting at the right and counting from zero."""
def _nth_digit(i: int, n: int) -> int {
    return (i // (10 ** n)) % 10;
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (_nth_digit(9, 2) == 0);;
}

test "t1" {
    assert (_nth_digit(123456, 2) == 4);;
}

test "t2" {
    assert (_nth_digit(9, 0) == 9);;
}

test "t3" {
    assert (_nth_digit(1, 2) == 0);;
}

test "t4" {
    assert (_nth_digit(1, 0) == 1);;
}

test "t5" {
    assert (_nth_digit(0, 2) == 0);;
}

test "t6" {
    assert (_nth_digit(12345, 10) == 0);;
}

test "t7" {
    assert (_nth_digit(1234567890, 0) == 0);;
}

test "t8" {
    assert (_nth_digit(1010, 1) == 1);;
}

test "t9" {
    assert (_nth_digit(12, 3) == 0);;
}

test "t10" {
    assert (_nth_digit(12, 2) == 0);;
}

test "t11" {
    assert (_nth_digit(1, 1) == 0);;
}

test "t12" {
    assert (_nth_digit(12345, 2) == 3);;
}

test "t13" {
    assert (_nth_digit(1234, 0) == 4);;
}

test "t14" {
    assert (_nth_digit(12345, 4) == 1);;
}

test "t15" {
    assert (_nth_digit(123, 2) == 1);;
}

test "t16" {
    assert (_nth_digit(123, 6) == 0);;
}

test "t17" {
    assert (_nth_digit(123, 5) == 0);;
}

test "t18" {
    assert (_nth_digit(12345, 1) == 4);;
}

test "t19" {
    assert (_nth_digit(123456, 3) == 3);;
}

test "t20" {
    assert (_nth_digit(9, 1) == 0);;
}

test "t21" {
    assert (_nth_digit(123456, 1) == 5);;
}

test "t22" {
    assert (_nth_digit(1234567890, 1) == 9);;
}

test "t23" {
    assert (_nth_digit(4321, 4) == 0);;
}

test "t24" {
    assert (_nth_digit(12345, 5) == 0);;
}

test "t25" {
    assert (_nth_digit(12345, 0) == 5);;
}

test "t26" {
    assert (_nth_digit(123, 3) == 0);;
}

te
```
</details>

---

### `fn-complete-46118` — unknown
- **Grader status:** `check_fail`  |  per_test: **0/0**
- **Reason:** Hidden test failed with no matched pattern — inspect error/per_test manually.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-46118 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
access attribute "split" for type "str | tuple[tuple[int | float | str, int | float | str], tuple[int | float | str, int | float | str]]"; attribute is missing from tuple[tuple[int | float | str, int | float | str], tuple[int | float | str, int | float | str]]
  --> /tmp/jac_eval_fn-complete-46118_vn1f3zgu/candidate.jac:9:34
    7 |             items = items.replace(s, "");
    8 | }
    9 |         (x1, x2, y1, y2) = items.split(",");
      |                                  ^^^^^
   10 |         out = ((int(float(x1)), int(float(x2))), (int(float(y1)), int(float(y2))));
   11 |     } else {
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""A tuple containing x- and y- slice tuples from a string or tuple."""
def tupletupleint(
    items: str | tuple[tuple[int | float | str, int | float | str], tuple[int | float | str, int | float | str]]
) -> tuple[tuple[int, int], tuple[int, int]] {
    if isinstance(items, str) {
        for s in " ()[]" {
            items = items.replace(s, "");
        }
        (x1, x2, y1, y2) = items.split(",");
        out = ((int(float(x1)), int(float(x2))), (int(float(y1)), int(float(y2))));
    } else {
        ((x1, x2), (y1, y2)) = items;
        out = ((int(float(x1)), int(float(x2))), (int(float(y1)), int(float(y2))));
    }
    return out;
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (tupletupleint("0,0,0,0") == ((0, 0), (0, 0)));;
}

test "t1" {
    assert (tupletupleint("0.0, 1.0, 1.0, 2.0") == ((0, 1), (1, 2)));;
}

test "t2" {
    assert (tupletupleint("5, 6, (7, 8)") == ((5, 6), (7, 8)));;
}

test "t3" {
    assert (tupletupleint("(( 1, 5 ), ( 2, 6 ))") == ((1, 5), (2, 6)));;
}

test "t4" {
    assert (tupletupleint("1, 2, 3, 4") == ((1, 2), (3, 4)));;
}

test "t5" {
    assert (tupletupleint(" 1, 2, 3, 4 ") == ((1, 2), (3, 4)));;
}

test "t6" {
    assert (tupletupleint("3.5, 8.1, 1.0, 5.0") == ((3, 8), (1, 5)));;
}

test "t7" {
    assert (tupletupleint("0, 1, 1, 2") == ((0, 1), (1, 2)));;
}

test "t8" {
    assert (tupletupleint("((1, 5), (2, 6))") == ((1, 5), (2, 6)));;
}

test "t9" {
    assert (tupletupleint("0,10,0,20") == ((0, 10), (0, 20)));;
}

test "t10" {
    assert (tupletupleint("(5, 6), (7, 8)") == ((5, 6), (7, 8)));;
}

test "t11" {
    assert (tupletupleint("0,1,1,2") == ((0, 1), (1, 2)));;
}

test "t12" {
    assert (tupletupleint("0,1,0,1") == ((0, 1), (0, 1)));;
}

test "t13" {
    assert (tupletupleint("1,2, 3, 4") == ((1, 2), (3, 4)));;
}

test "t14" {
    assert (tupletupleint(((1, 2), (3, 4))) == ((1, 2), (3, 4)));;
}

test "t15" {
    assert (tupletupleint(((1, 5), (2, 6))) == ((1, 5), (2, 6)));;
}

test "t16" {
    assert (tupletupleint("5, 6, 7, 8") == ((5, 6), (7, 8)));;
}

test "t17" {
    assert (tupletupleint("(( 1.0, 5.0 ), ( 2.0, 6.0 ))") == ((1, 5), (2, 6)));;
}

test "t18" {
    assert (tuplet
```
</details>

---

### `fn-complete-51610` — jac_typecheck_or_data
- **Grader status:** `check_fail`  |  per_test: **0/0**
- **Reason:** E1002 return type mismatch (float vs int). Either the reference is genuinely mistyped (dataset), or jac's type checker got stricter and now rejects previously accepted code.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-51610 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
✖ Error: error[E1002]: Cannot return float, expected int
  --> /tmp/jac_eval_fn-complete-51610_p_6np7i1/candidate.jac:19:5
   17 | return 1;
   18 |     }
   19 |     return constant * (2 ** (level + 1)) - 1;
      |     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   20 | }
   21 |
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""
    The number of samples in an exponentially growing 1D quadrature rule of
    a given level.

    Parameters
    ----------
    level : integer
       The level of the quadrature rule

    Return
    ------
    num_samples_1d : integer
        The number of samples in the quadrature rule
    """
def exponential_growth(level: int, constant: int = 1) -> int {
    if level == 0 {
        return 1;
    }
    return constant * (2 ** (level + 1)) - 1;
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (exponential_growth(5) == 63);;
}

test "t1" {
    assert (exponential_growth(9) == 1023);;
}

test "t2" {
    assert (exponential_growth(12) == 8191);;
}

test "t3" {
    assert (exponential_growth(2) == 7);;
}

test "t4" {
    assert (exponential_growth(4) == 31);;
}

test "t5" {
    assert (exponential_growth(1) == 3);;
}

test "t6" {
    assert (exponential_growth(3) == 15);;
}

test "t7" {
    assert (exponential_growth(6) == 127);;
}

test "t8" {
    assert (exponential_growth(13) == 16383);;
}

test "t9" {
    assert (exponential_growth(7) == 255);;
}

test "t10" {
    assert (exponential_growth(11) == 4095);;
}

test "t11" {
    assert (exponential_growth(10) == 2047);;
}

test "t12" {
    assert (exponential_growth(14) == 32767);;
}

test "t13" {
    assert (exponential_growth(0) == 1);;
}

test "t14" {
    assert (exponential_growth(0, 2) == 1);;
}

test "t15" {
    assert (exponential_growth(8) == 511);;
}

test "t16" {
    assert (exponential_growth(15) == 65535);;
}
```
</details>

---

### `fn-complete-337435` — jac_native_runtime
- **Grader status:** `test_fail`  |  per_test: **19/23**
- **Reason:** Crash in jac's native test invocation path (`invoke_native_test`). The reference compiled but the native runner faulted while executing tests.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-337435 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
invoke_native_test
E   AssertionError: assertion failed at /tmp/jac_eval_fn-complete-337435_iv6r08au/guard.jac:33
=========================== short test summary info ============================
FAILED guard.jac::t9 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c0...
FAILED guard.jac::t1 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c0...
FAILED guard.jac::t2 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c0...
FAILED guard.jac::t6 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c0...
========================= 4 failed, 19 passed in 5.41s =========================
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""Remove an element from a list."""
def del_elements(ele: int, lst: list[int]) -> list[int] {
    new_lst = lst.copy();
    new_lst.remove(ele);
    return new_lst;
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (del_elements(1, [0, 1, 2, 3, 4, 1, 1]) == [0, 2, 3, 4, 1, 1]);;
}

test "t1" {
    assert (del_elements(2, [2]) == []);;
}

test "t2" {
    assert (del_elements(0, [0]) == []);;
}

test "t3" {
    assert (del_elements(2, [0, 1, 2]) == [0, 1]);;
}

test "t4" {
    assert (del_elements(3, [3, 2, 1, 3]) == [2, 1, 3]);;
}

test "t5" {
    assert (del_elements(2, [1, 2, 3]) == [1, 3]);;
}

test "t6" {
    assert (del_elements(4, [4]) == []);;
}

test "t7" {
    assert (del_elements(1, [1, 2, 3]) == [2, 3]);;
}

test "t8" {
    assert (del_elements(4, [1, 2, 3, 4]) == [1, 2, 3]);;
}

test "t9" {
    assert (del_elements(5, [5]) == []);;
}

test "t10" {
    assert (del_elements(0, [0, 1, 2]) == [1, 2]);;
}

test "t11" {
    assert (del_elements(3, [1, 2, 3, 4]) == [1, 2, 4]);;
}

test "t12" {
    assert (del_elements(2, [1, 2, 3, 2]) == [1, 3, 2]);;
}

test "t13" {
    assert (del_elements(1, [2, 3, 1, 2]) == [2, 3, 2]);;
}

test "t14" {
    assert (del_elements(1, [0, 1, 2]) == [0, 2]);;
}

test "t15" {
    assert (del_elements(1, [1, 2, 3, 4]) == [2, 3, 4]);;
}

test "t16" {
    assert (del_elements(3, [3, 2, 1]) == [2, 1]);;
}

test "t17" {
    assert (del_elements(5, [1, 2, 3, 4, 5]) == [1, 2, 3, 4]);;
}

test "t18" {
    assert (del_elements(3, [1, 2, 3]) == [1, 2]);;
}

test "t19" {
    assert (del_elements(4, [3, 4]) == [3]);;
}

test "t20" {
    assert (del_elements(3, [1, 2, 3, 4, 5]) == [1, 2, 4, 5]);;
}

test "t21" {
    assert (del_elements(2, [0,
```
</details>

---

### `fn-complete-292243` — unknown
- **Grader status:** `test_fail`  |  per_test: **11/11**
- **Reason:** Hidden test failed with no matched pattern — inspect error/per_test manually.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-292243 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
36.0, anyio-4.14.2
created: 32/32 workers
32 workers [0 items]


==================================== ERRORS ====================================
__________________________ ERROR collecting guard.jac __________________________
failed to import Jac test module /tmp/jac_eval_fn-complete-292243_5d28yyyx/guard.jac: ModuleNotFoundError: No module named 'numpy'
=========================== short test summary info ============================
ERROR guard.jac - failed to import Jac test module /tmp/jac_eval_fn-complete-...
=============================== 1 error in 2.32s ===============================
```
</details>

<details><summary>candidate.jac</summary>

```jac
import numpy;

"""Spectral test to determine potential snow

Uses the 9.85C (283K) threshold defined in Zhu, Woodcock 2015

Parameters
----------
ndsi: ndarray
green: ndarray
nir: ndarray
tirs1: ndarray

Output
------
ndarray:
    boolean, True is potential snow
"""
def potential_snow_layer(ndsi: numpy.ndarray, green: numpy.ndarray, nir: numpy.ndarray, tirs1: numpy.ndarray) -> numpy.ndarray {
    return (ndsi > 0.15) & (tirs1 < 9.85) & (nir > 0.11) & (green > 0.1);
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (potential_snow_layer(1, 1, 1, 9.85) == False);;
}

test "t1" {
    assert (potential_snow_layer(1, 0, 1, 0) == False);;
}

test "t2" {
    assert (potential_snow_layer(1, 1, 0, 0) == False);;
}

test "t3" {
    assert (potential_snow_layer(100, 100, 100, 100) == False);;
}

test "t4" {
    assert (potential_snow_layer(1.0, 10.0, 10.0, 283.15) == False);;
}

test "t5" {
    assert (potential_snow_layer(0, 1, 1, 0) == False);;
}

test "t6" {
    assert (potential_snow_layer(1, 1, 1, 0) == True);;
}

test "t7" {
    assert (potential_snow_layer(0, 0, 0, 0) == False);;
}

test "t8" {
    assert (potential_snow_layer(1, 1, 1, 9.84) == True);;
}

test "t9" {
    assert (potential_snow_layer(0.2, 0.0, 0.1, 1) == False);;
}

test "t10" {
    assert (potential_snow_layer(0.2, 0.1, 0.11, 9.84) == False);;
}
```
</details>

---

### `fn-complete-262051` — jac_native_runtime
- **Grader status:** `test_fail`  |  per_test: **9/25**
- **Reason:** Crash in jac's Rust runtime module (`c/rt/…`). Native execution path fault.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-262051 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
c/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t22 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t11 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t13 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t10 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t15 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t17 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
========================= 16 failed, 9 passed in 5.40s =========================
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""Remove any number in a string."""
def remove_numbers(s: str) -> str {
    return ''.join([i for i in s if not i.isdigit()]);
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (remove_numbers("10101010") == "") , "All numbers were removed";;
}

test "t1" {
    assert (remove_numbers("1234567890") == "");;
}

test "t2" {
    assert (remove_numbers("abc12345") == "abc");;
}

test "t3" {
    assert (remove_numbers('abc123abc') == 'abcabc');;
}

test "t4" {
    assert (
        remove_numbers('There are no numbers in this string')
        == 'There are no numbers in this string'
    );;
}

test "t5" {
    assert (remove_numbers('Hello World') == 'Hello World');;
}

test "t6" {
    assert (remove_numbers("2021 isn't a year") == " isn't a year");;
}

test "t7" {
    assert (remove_numbers("1234567890-") == "-");;
}

test "t8" {
    assert (remove_numbers("") == "") , "Empty string passed";;
}

test "t9" {
    assert (remove_numbers("hello") == 'hello');;
}

test "t10" {
    assert (remove_numbers('Hello123World') == 'HelloWorld');;
}

test "t11" {
    assert (
        remove_numbers("Hi there! 23 is my favorite number.")
        == "Hi there!  is my favorite number."
    );;
}

test "t12" {
    assert (
        remove_numbers("What is the weather like tomorrow?")
        == "What is the weather like tomorrow?"
    );;
}

test "t13" {
    assert (
        remove_numbers("The 5 boxing wizards jump quickly.")
        == "The  boxing wizards jump quickly."
    );;
}

test "t14" {
    assert (remove_numbers('1234567890') == '');;
}

test "t15" {
    assert (remove_numbers('abc 123 abc') == 'abc  abc');;
}

test "t16" {
    assert (remov
```
</details>

---

### `fn-complete-340173` — jac_native_runtime
- **Grader status:** `test_fail`  |  per_test: **50/54**
- **Reason:** Crash in jac's native test invocation path (`invoke_native_test`). The reference compiled but the native runner faulted while executing tests.
- **Reproduce:**
  ```bash
  cd cases/fn-complete-340173 && jac check candidate.jac && jac test guard.jac
  ```

<details><summary>error (first 1200 chars)</summary>

```
invoke_native_test
E   AssertionError: assertion failed at /tmp/jac_eval_fn-complete-340173_9be3tr4u/guard.jac:140
=========================== short test summary info ============================
FAILED guard.jac::t23 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t12 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t47 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
FAILED guard.jac::t32 -   /home/imrui/.cache/jac/rt/eb426fc191f2a5f1-ec05ca5c...
========================= 4 failed, 50 passed in 6.05s =========================
```
</details>

<details><summary>candidate.jac</summary>

```jac
"""scalar multiply a list"""
def scalarmult(scalar: int, list1: list[int]) -> list[int] {
    return [scalar * elt for elt in list1];
}
```
</details>

<details><summary>hidden tests.jac (truncated)</summary>

```jac
test "t0" {
    assert (scalarmult(1, [1, 2, 3]) == [1, 2, 3]);;
}

test "t1" {
    assert (scalarmult(2, [1, 2]) == [2, 4]);;
}

test "t2" {
    assert (scalarmult(5, [2, 4, 6]) == [10, 20, 30]);;
}

test "t3" {
    assert (scalarmult(5, [3, 4]) == [15, 20]);;
}

test "t4" {
    assert (scalarmult(0, [3, 4, 5]) == [0, 0, 0]);;
}

test "t5" {
    assert (
        scalarmult(1, [10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
        == [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    );;
}

test "t6" {
    assert (scalarmult(5, [1, 2, 3]) == [5, 10, 15]);;
}

test "t7" {
    assert (scalarmult(2, [5]) == [10]);;
}

test "t8" {
    assert (scalarmult(1, [2, 3]) == [2, 3]);;
}

test "t9" {
    assert (scalarmult(4, [-1, 0, 1]) == [-4, 0, 4]);;
}

test "t10" {
    assert (scalarmult(4, [3, 4]) == [12, 16]);;
}

test "t11" {
    assert (scalarmult(5, [1, 3, 5, 7, 9]) == [5, 15, 25, 35, 45]);;
}

test "t12" {
    assert (scalarmult(1, []) == []);;
}

test "t13" {
    assert (scalarmult(5, [5, 1, 2, 10, 3]) == [25, 5, 10, 50, 15]);;
}

test "t14" {
    assert (
        scalarmult(-1, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        == [-1, -2, -3, -4, -5, -6, -7, -8, -9, -10]
    );;
}

test "t15" {
    assert (scalarmult(2, [1, 2, 3]) == [2, 4, 6]);;
}

test "t16" {
    assert (scalarmult(4, [1, 3, 5, 7]) == [4, 12, 20, 28]);;
}

test "t17" {
    assert (scalarmult(2, [1, 1, 1, 1]) == [2, 2, 2, 2]);;
}

test "t18" {
    assert (scalarmult(1, [1, 1, 1, 1]) == [1, 1, 1, 1]);;
}

test "t19" {
    ass
```
</details>

---

## Failure-class comparison — 2026-09-12 (dev, n=200) vs 2026-09-13 (test, n=500)

| Class                                | 09-12 dev | 09-13 test |
|---|---:|---:|
| E5043 bytecode Store/Load            |  1 |  0 |
| E50xx native-lowering limits         |  5 |  0 |
| E1053 type-check                     |  2 |  0 |
| E1002 return-type (float vs int)     |  1 |  2 |
| jac native-runtime crash             |  4 |  4 |
| jac binary crash                     |  0 |  1 |
| embedded postgres infra              |  2 |  0 |
| unknown / other                      |  0 |  2 |
| **broken rate**                      | **7.5%** | **1.8%** |

Compile-side bugs (E5043, E50xx, E1053) and the embedded-postgres infra are fully resolved since 9/12. The residual failures are jac native-runtime crashes on different task IDs plus a couple of E1002 type-check hits that may reflect either dataset quality or stricter jac type inference — worth a per-case eyeball rather than a broad fix.
